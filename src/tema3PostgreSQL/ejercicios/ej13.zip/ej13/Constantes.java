package tema3PostgreSQL.ejercicios.ej13;

public class Constantes {

}
